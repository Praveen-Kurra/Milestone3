package com.reusable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GetDateTime {
	public static  String getDatetimeFormat() {
		
		DateFormat cusFormat=new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		
		Date date=new Date();
		
	return	cusFormat.format(date);
	
	}
}
